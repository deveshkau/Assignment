/**
 * @Author - Ankit Tiwari
 * Roll No - CSE/16148/138
 * Reg No - 138
 */

#if !defined(HEADER_FILE)
#define HEADER_FILE
using namespace std;

/* Regular Expressions */
const regex identifierRe("^[a-zA-Z][a-zA-Z0-9]*");
const regex spaceRe("^ +");
const regex newLineRe("^[\n]");
const regex carrReturnRe("^[\r]");
const regex integerRe("^[0-9]+");
const regex commentRe("^//.*");
const regex opRe("^[\\+\\-\\*\\/%=]");
const regex sepRe("^[;,(){}]");
const regex NoTokenRe("^.");

/* Token Type */
const int NO_TOKEN = 0;
const int ID = 1;
const int IC = 2;
const int BINOP = 3;
const int SEPARATOR = 4;
const int WHITESPACE = 5;

/* definition of a token */
struct token {
  int line;
  int position;
  int type;
  string val;
};

void printData(string, string, int, int);
string fillBuffer(string);
token nextToken(string&);

#endif // HEADER_FILE

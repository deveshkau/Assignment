/**
 * @Author - Ankit Tiwari
 * Roll No - CSE/16148/138
 * Reg No - 138
 */

#include<iostream>
#include<regex>
#include<fstream>
#include "138.2.h"
using namespace std;

int main(int argc, char* argv[]) {

  if(argc < 2) {
    cout<<"Please provide the input file name."<<endl;
    return -1;
  }

  // fillBuffer returns the content of the file
  string str = fillBuffer(argv[1]);

  token newToken;
  while (str.length() > 0) {
    newToken = nextToken(str);
    switch (newToken.type) {
      case IC:
      printData("IC", newToken.val, newToken.line, newToken.position);
        break;
      case ID:
      printData("ID", newToken.val, newToken.line, newToken.position);
        break;
      case BINOP:
      printData("BINOP", newToken.val, newToken.line, newToken.position);
        break;
      case NO_TOKEN:
      printData("NO_TOKEN", newToken.val, newToken.line, newToken.position);
        break;
      case SEPARATOR:
      printData("SEPARATOR", newToken.val, newToken.line, newToken.position);
        break;
      default:
        break;
    }
  }
  cout <<"End of File:"<<endl;

  return 0;
}
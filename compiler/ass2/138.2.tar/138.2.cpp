/**
 * @Author - Ankit Tiwari
 * Roll No - CSE/16148/138
 * Reg No - 138
 */

#include<iostream>
#include<regex>
#include<fstream>
#include "138.2.h"
using namespace std;

// Prints a token to the console
void printData(string tokenType, string token, int line, int position) {
  cout << tokenType << ": " << token << " <Line: " << line << ", Position: " << position << ">" << endl;
}

// Reads the passed file and returns the content as string
string fillBuffer(string fileName) {
  ifstream file(fileName);
  string str;
  string file_contents;
  while (getline(file, str))
  {
    file_contents += str;
    file_contents.push_back('\n');
  }
  return file_contents;
}

// Returns the next token matched in the passed string
token nextToken(string &str) {
  static int line = 1;
  static int position = 1;
  smatch m;
  token t;

  if (regex_search(str, m, commentRe)) {
    t.position = position;
    position += m.str(0).length();
    str = str.substr(m.str(0).length());
    t.type = WHITESPACE;
  }

  else if (regex_search(str, m, identifierRe)) {
    t.position = position;
    t.val = m.str(0);
    position += m.str(0).length();
    str = str.substr(m.str(0).length());
    t.type = ID;
  }

  else if (regex_search(str, m, integerRe)) {
    t.position = position;
    t.val = m.str(0);
    position += m.str(0).length();
    str = str.substr(m.str(0).length());
    t.type = IC;
  }

  else if (regex_search(str, m, opRe)) {
    t.position = position;
    t.val = m.str(0);
    position += m.str(0).length();
    str = str.substr(m.str(0).length());
    t.type = BINOP;
  }

  else if (regex_search(str, m, sepRe)) {
    t.position = position;
    t.val = m.str(0);
    position += m.str(0).length();
    str = str.substr(m.str(0).length());
    t.type = SEPARATOR;
  }

  else if (regex_search(str, m, spaceRe)) {
    t.position = position;
    position += m.str(0).length();
    str = str.substr(m.str(0).length());
    t.type = WHITESPACE;
  }

  else if (regex_search(str, m, newLineRe)) {
    position += m.str(0).length();
    str = str.substr(m.str(0).length());
    line++;
    position = 1;
    t.type = WHITESPACE;
  }

  else if (regex_search(str, m, carrReturnRe)) {
    str = str.substr(m.str(0).length());
    t.type = WHITESPACE;
  }

  else if (regex_search(str, m, NoTokenRe)) {
    t.position = position;
    t.val = m.str(0);
    position += m.str(0).length();
    str = str.substr(m.str(0).length());
    t.type = NO_TOKEN;
  }

  t.line = line;

  return t;
}
